package pt.meta_II.tppd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TppdApplicationTests {

    @Test
    void contextLoads() {
    }

}
